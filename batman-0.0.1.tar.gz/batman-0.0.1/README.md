# Use PyPA build to create Python CLI applications
Deliberately simple example of how to create & package Python CLI
applications using the [PyPA setuptools build
tool](https://setuptools.readthedocs.io/).

## Build Steps
```
a_build.sh

```

## Test Deploy Steps
```
b_deploy.sh

```

