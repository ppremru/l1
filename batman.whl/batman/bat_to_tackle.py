''' batman module '''

def convert():
    print('creates output file')


def hello():
    print('Hello Dolly')


if __name__ == "__main__":
    """This runs when you execute 'python3 batman/bat_to_tackle.py'"""
    hello()
